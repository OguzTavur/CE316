#include <stdio.h>

int main(int argc,char *argv[])
{

    printf("%s %s",argv[1],argv[2]);

    return 0;
}